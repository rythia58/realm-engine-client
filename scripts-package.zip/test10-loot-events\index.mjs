import { RealmEngine } from '@realmengine/sdk';
const { log, loot, events } = RealmEngine;

export default class LootTest {
  bagCount = 0;
  async onStart() {
    loot.onBagDropped((e) => {
      this.bagCount++;
      const items = e.bag.items.map(i => i.itemName ?? i.objectType).join(', ');
      log.info('bag #' + this.bagCount + ' dropped: ' + items);
    });
    events.onItemPickedUp((e) => {
      log.info('picked up: ' + (e.itemName ?? e.objectType) + ' in slot ' + e.slotIndex);
    });
    log.info('watching for loot — kill something');
  }
  async onLoop() { return 2000; }
  async onStop() { log.info('saw ' + this.bagCount + ' bags'); }
}