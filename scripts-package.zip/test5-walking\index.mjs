import { RealmEngine } from '@realmengine/sdk';
const { log, walking, self } = RealmEngine;

export default class WalkTest {
  async onStart() {
    const x = self.getX();
    const y = self.getY();

    const r1 = await walking.walkToAsync(x + 5, y, { timeoutMs: 8000 });
    log.info('short walk: ' + r1);

    const r2 = await walking.walkToAsync(self.getX(), self.getY(), { reachThreshold: 1.0 });
    log.info('same tile: ' + r2);

    const r3 = await walking.walkToAsync(x + 500, y, { timeoutMs: 500 });
    log.info('timeout: ' + r3);

    const p = walking.walkToAsync(x + 30, y, { timeoutMs: 15000 });
    await new Promise(r => setTimeout(r, 1000));
    walking.stopMoving();
    const r4 = await p;
    log.info('cancelled: ' + r4);
    log.info('isMoving: ' + walking.isMoving());
  }
  async onLoop() { return -1; }
  async onStop() {}
}
