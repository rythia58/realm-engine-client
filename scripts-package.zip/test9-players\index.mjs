import { RealmEngine } from '@realmengine/sdk';
const { log, players, self } = RealmEngine;

export default class PlayersTest {
  async onStart() {
    log.info('player count: ' + players.count());
    const all = players.getAll();
    log.info('getAll length: ' + all.length);
    const nearest = players.getNearest();
    log.info('nearest: ' + (nearest?.name ?? 'none')
      + ' hp: ' + (nearest?.hp ?? '-'));
    const me = players.find(self.getName());
    log.info('find self: ' + (me ? 'found' : 'not found'));
  }
  async onLoop() { return -1; }
  async onStop() {}
}
