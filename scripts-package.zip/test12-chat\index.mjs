import { RealmEngine } from '@realmengine/sdk';
const { log, chat, self } = RealmEngine;

export default class ChatTest {
  async onStart() {
    const name = self.getName();
    log.info('sending /tell to self: ' + name);
    chat.say('/tell ' + name + ' hello from script');
    log.info('sent');
    chat.notify('Script test notification');
    log.info('notify sent');
  }
  async onLoop() { return -1; }
  async onStop() {}
}
