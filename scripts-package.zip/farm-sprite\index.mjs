import { RealmEngine } from '@realmengine/sdk';
const { log, self, world, enemies, walking, loot, events, inventory } = RealmEngine;

// ── Pickup options ────────────────────────────────────────────────────────────
const PICKUP_OPTS = {
  includeUTs: true,
  includeSTs: true,
  includeStatPotions: true,
  includeLifeManaPotions: true,
  includeMarks: false,
  includeEggs: false,
};

// ── Tuning ────────────────────────────────────────────────────────────────────
const ENEMY_REACH      = 3.0;
const ENEMY_TIMEOUT_MS = 5000;
const ENEMY_RETRIES    = 8;
const LOOT_RADIUS      = 5;
const NO_ENEMY_NEXUS_TICKS = 5;   // consecutive no-enemy ticks before nexusing

export default class FarmSprite {
  noEnemyTicks = 0;

  async onStart() {
    log.info('Farm Sprite World started — HP: ' + self.getHP() + '/' + self.getMaxHP());
    this.noEnemyTicks = 0;

    events.onDungeonEntered((e) => {
      this.noEnemyTicks = 0;
      log.info('Entered: ' + e.dungeonName);
    });
  }

  async onLoop() {
    // ── Nexus ────────────────────────────────────────────────────────────────
    if (world.isNexus()) {
      this.noEnemyTicks = 0;
      const ok = await world.enterRealm();
      if (!ok) {
        walking.walkToTopWall();
        return 1000;
      }
      return 2000;
    }

    // ── Realm ────────────────────────────────────────────────────────────────
    if (world.isRealm()) {
      this.noEnemyTicks = 0;

      // Sprite World portal visible? Enter immediately.
      const entered = await world.enterPortal('Sprite World');
      if (entered) {
        log.info('Sprite World portal found — entering!');
        return 3000;
      }

      // Pick up nearby loot
      for (const bag of loot.getNearbyBags(LOOT_RADIUS)) {
        loot.pickupId(bag.objectId, PICKUP_OPTS);
      }

      if (inventory.isFull()) {
        log.info('Inventory full — nexusing');
        walking.nexus();
        return 2000;
      }

      // Chase nearest enemy to generate portal drops
      const enemy = enemies.getNearest();
      if (enemy) {
        await walking.walkToAsync(enemy.position.x, enemy.position.y, {
          timeoutMs: ENEMY_TIMEOUT_MS,
          reachThreshold: ENEMY_REACH,
          maxRetries: ENEMY_RETRIES,
        });
      }

      return 100;
    }

    // ── Dungeon (Sprite World) ────────────────────────────────────────────────
    if (world.isDungeon()) {
      // Pick up loot
      for (const bag of loot.getNearbyBags(LOOT_RADIUS)) {
        loot.pickupId(bag.objectId, PICKUP_OPTS);
      }

      if (inventory.isFull()) {
        log.info('Inventory full — nexusing from dungeon');
        walking.nexus();
        return 2000;
      }

      const enemy = enemies.getNearest();
      if (enemy) {
        this.noEnemyTicks = 0;
        await walking.walkToAsync(enemy.position.x, enemy.position.y, {
          timeoutMs: ENEMY_TIMEOUT_MS,
          reachThreshold: ENEMY_REACH,
          maxRetries: ENEMY_RETRIES,
        });
      } else {
        this.noEnemyTicks++;
        if (this.noEnemyTicks >= NO_ENEMY_NEXUS_TICKS) {
          log.info('Dungeon cleared — nexusing');
          this.noEnemyTicks = 0;
          walking.nexus();
          return 2000;
        }
      }

      return 200;
    }

    return 500;
  }

  async onStop() {
    walking.stopMoving();
    log.info('Farm Sprite World stopped');
  }
}
