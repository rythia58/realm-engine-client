import { RealmEngine } from '@realmengine/sdk';
const { log } = RealmEngine;

export default class LogTest {
  async onStart() {
    log.info('info line');
    log.warn('warn line');
    log.error('error line');
  }
  async onLoop() { return -1; }
  async onStop() { log.info('stopped'); }
}
