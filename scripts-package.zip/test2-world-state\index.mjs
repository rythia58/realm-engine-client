import { RealmEngine } from '@realmengine/sdk';
const { log, world } = RealmEngine;

export default class WorldTest {
  async onStart() {
    log.info('map: ' + world.getName());
    log.info('isNexus:' + world.isNexus() + ' isRealm:' + world.isRealm()
      + ' isDungeon:' + world.isDungeon() + ' isVault:' + world.isVault());
  }
  async onLoop() { return -1; }
  async onStop() {}
}
