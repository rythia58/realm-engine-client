import { RealmEngine } from '@realmengine/sdk';
const { log, self } = RealmEngine;

export default class SelfStatsTest {
  async onStart() {
    log.info('name: ' + self.getName() + ' class: ' + self.getClass());
    log.info('hp: ' + self.getHP() + '/' + self.getMaxHP()
      + ' mp: ' + self.getMP() + '/' + self.getMaxMP());
    log.info('atk: ' + self.getAtk() + ' def: ' + self.getDef()
      + ' spd: ' + self.getSpd() + ' dex: ' + self.getDex()
      + ' vit: ' + self.getVit() + ' wis: ' + self.getWis());
    log.info('weapon: ' + (self.getWeapon()?.name ?? 'none'));
    log.info('ability: ' + (self.getAbility()?.name ?? 'none'));
    log.info('armor: ' + (self.getArmor()?.name ?? 'none'));
    log.info('ring: ' + (self.getRing()?.name ?? 'none'));
    log.info('fame: ' + self.getCharacterFame()
      + ' accountFame: ' + self.getAccountFame());
  }
  async onLoop() { return -1; }
  async onStop() {}
}
