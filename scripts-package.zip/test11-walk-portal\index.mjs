import { RealmEngine } from '@realmengine/sdk';
const { log, walking, world } = RealmEngine;

export default class WalkPortalTest {
  async onStart() {
    log.info('current map: ' + world.getName());
    const moved = walking.walkToNearestPortal();
    log.info('walkToNearestPortal started: ' + moved);
    await new Promise(r => setTimeout(r, 10000));
    walking.stopMoving();
    log.info('stopped at: ' + RealmEngine.self.getX().toFixed(1)
      + ',' + RealmEngine.self.getY().toFixed(1));
  }
  async onLoop() { return -1; }
  async onStop() {}
}