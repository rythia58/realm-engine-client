import { RealmEngine } from '@realmengine/sdk';
const { log, enemies } = RealmEngine;

export default class PollTest {
  ticks = 0;
  async onStart() { log.info('polling started'); }
  async onLoop() {
    this.ticks++;
    log.info(`tick ${this.ticks}: ${enemies.count()} enemies`);
    if (this.ticks >= 5) return -1;
    return 1000;
  }
  async onStop() { log.info('done after ' + this.ticks + ' ticks'); }
}
