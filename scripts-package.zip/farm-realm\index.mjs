import { RealmEngine } from '@realmengine/sdk';
const { log, self, world, enemies, walking, loot, events, inventory } = RealmEngine;

// ── Pickup options ────────────────────────────────────────────────────────────
const PICKUP_OPTS = {
  includeUTs: true,
  includeSTs: true,
  includeStatPotions: true,
  includeLifeManaPotions: true,
  includeMarks: false,
  includeEggs: false,
};

// ── Tuning ────────────────────────────────────────────────────────────────────
const ENEMY_REACH      = 3.0;   // tiles
const ENEMY_TIMEOUT_MS = 5000;
const ENEMY_RETRIES    = 8;
const LOOT_RADIUS      = 5;     // tiles

export default class FarmRealm {
  async onStart() {
    log.info('Farm Realm started — HP: ' + self.getHP() + '/' + self.getMaxHP());

    events.onDungeonEntered((e) => {
      log.info('Entered dungeon: ' + e.dungeonName);
    });

    events.onDungeonExited(() => {
      log.info('Exited dungeon');
    });
  }

  async onLoop() {
    // ── Nexus ────────────────────────────────────────────────────────────────
    if (world.isNexus()) {
      // enterRealm: finds nearest realm portal, walks to it, AND sends USEPORTAL.
      // Returns false only when no realm portal is in world state yet.
      const ok = await world.enterRealm();
      if (!ok) {
        // Realm portals not in range yet — walk straight up toward the top of
        // the nexus where realm portals spawn (player starts at bottom).
        walking.walkToTopWall();
        return 1000;
      }
      // USEPORTAL sent — wait for map transition
      return 2000;
    }

    // ── Realm ────────────────────────────────────────────────────────────────
    if (world.isRealm()) {
      // Pick up nearby loot first
      const bags = loot.getNearbyBags(LOOT_RADIUS);
      for (const bag of bags) {
        loot.pickupId(bag.objectId, PICKUP_OPTS);
      }

      // Full inventory → nexus to offload
      if (inventory.isFull()) {
        log.info('Inventory full — nexusing');
        walking.nexus();
        return 2000;
      }

      // Walk toward nearest enemy
      const enemy = enemies.getNearest();
      if (enemy) {
        await walking.walkToAsync(enemy.position.x, enemy.position.y, {
          timeoutMs: ENEMY_TIMEOUT_MS,
          reachThreshold: ENEMY_REACH,
          maxRetries: ENEMY_RETRIES,
        });
      } else {
        return 500;
      }

      return 100;
    }

    // ── Dungeon ──────────────────────────────────────────────────────────────
    if (world.isDungeon()) {
      return 1000;
    }

    return 500;
  }

  async onStop() {
    walking.stopMoving();
    log.info('Farm Realm stopped');
  }
}
