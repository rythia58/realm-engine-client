import { RealmEngine } from '@realmengine/sdk';
const { log, inventory } = RealmEngine;

export default class InventoryTest {
  async onStart() {
    const allSlots = inventory.getAll();
    const occupied = allSlots
      .map((typeId, slotIndex) => ({ typeId, slotIndex }))
      .filter(({ typeId }) => typeId >= 0);
    log.info('slots occupied: ' + occupied.length);
    occupied.forEach(({ typeId, slotIndex }) =>
      log.info('  ' + typeId + '; ' + slotIndex));
    log.info('free slots: ' + inventory.getFreeSlots());
    log.info('is full: ' + inventory.isFull());
  }
  async onLoop() { return -1; }
  async onStop() {}
}
