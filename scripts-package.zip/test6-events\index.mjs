import { RealmEngine } from '@realmengine/sdk';
const { log, events, world } = RealmEngine;

export default class EventTest {
  async onStart() {
    events.onRealmClosed((e) => log.info('REALM CLOSED: ' + e.previousMapName));
    events.onDungeonEntered((e) => log.info('ENTERED DUNGEON: ' + e.dungeonName));
    events.onDungeonExited((e) => log.info('EXITED DUNGEON: ' + e.previousDungeonName));
    events.onPortalOpened((e) => log.info('PORTAL OPENED: ' + e.portalName));
    events.onMapChanged(() => log.info('MAP CHANGED to: ' + world.getName()));
    log.info('listening for events — enter/exit a dungeon to test');
  }
  async onLoop() { return 5000; }
  async onStop() {}
}
