import { RealmEngine } from '@realmengine/sdk';
const { log, walking, world } = RealmEngine;

export default class WalkPortalAsyncTest {
  async onStart() {
    log.info('map: ' + world.getName());
    const result = await walking.walkToAsync(128, 128, { timeoutMs: 15000 });
    log.info('walk to center: ' + result);
    log.info('pos: ' + RealmEngine.self.getX().toFixed(1)
      + ',' + RealmEngine.self.getY().toFixed(1));
  }
  async onLoop() { return -1; }
  async onStop() {}
}
