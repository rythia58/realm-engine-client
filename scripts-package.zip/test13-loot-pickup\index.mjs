import { RealmEngine } from '@realmengine/sdk';
const { log, loot } = RealmEngine;

export default class LootPickupTest {
  async onStart() {
    log.info('bags visible: ' + loot.getBags().length);
    const bags = loot.getNearbyBags(3.0);
    log.info('bags within 3 tiles: ' + bags.length);
    if (bags.length > 0) {
      const bag = bags[0];
      log.info('bag has ' + bag.items.length + ' items');
      bag.items.forEach((item, i) => {
        log.info('  slot ' + i + ': ' + (item.itemName ?? item.objectType));
      });
      if (bag.items.length > 0) {
        const sent = loot.pickup(bag, 0);
        log.info('pickup sent: ' + sent);
      }
    } else {
      log.info('no nearby bags — kill something first');
    }
  }
  async onLoop() { return -1; }
  async onStop() {}
}
