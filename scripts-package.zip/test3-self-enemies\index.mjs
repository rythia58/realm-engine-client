import { RealmEngine } from '@realmengine/sdk';
const { log, self, enemies } = RealmEngine;

export default class EntityTest {
  async onStart() {
    log.info('pos: ' + self.getX().toFixed(1) + ',' + self.getY().toFixed(1));
    log.info('hp: ' + self.getHP());
    log.info('enemies: ' + enemies.count());
    const nearest = enemies.getNearest();
    log.info('nearest: ' + (nearest?.name ?? 'none'));
    const boss = enemies.getBoss();
    log.info('boss: ' + (boss?.name ?? 'none'));
  }
  async onLoop() { return -1; }
  async onStop() {}
}
